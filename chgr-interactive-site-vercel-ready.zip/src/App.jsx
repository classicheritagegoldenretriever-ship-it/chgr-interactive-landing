import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Dog, Users, DoorOpen, Play, Info, PawPrint, Phone, Mail, MapPin,
  ExternalLink, ClipboardList, ShieldCheck
} from "lucide-react";

/** Classic Heritage – Interactive Landing (Standalone Vite + React) */

const CONFIG = {
  PRICING: { BASE: 3500, TRAINING: 1200, DELIVERY: 450 }, // TODO: replace with real numbers
  LINKS: {
    APPLY: "https://classicheritagegoldenretrievers.com/apply",
    PRICING: "https://classicheritagegoldenretrievers.com/pricing",
    CONTACT: "https://classicheritagegoldenretrievers.com/contact",
  },
  MEDIA: {
    STAFF: [
      { name: "Owner One", role: "Breeder / Handler", img: "https://via.placeholder.com/800x450?text=Owner+One" },
      { name: "Owner Two", role: "Puppy Matching & Client Care", img: "https://via.placeholder.com/800x450?text=Owner+Two" },
    ],
    PACK: [
      "https://via.placeholder.com/1200x1200?text=Pack+1",
      "https://via.placeholder.com/1200x1200?text=Pack+2",
      "https://via.placeholder.com/1200x1200?text=Pack+3",
      "https://via.placeholder.com/1200x1200?text=Pack+4",
    ],
    OUTSIDE_POSTER: "https://via.placeholder.com/1280x720?text=Outdoor+Yard+Video+Poster",
    OUTSIDE_VIDEO: "https://www.w3schools.com/html/mov_bbb.mp4",
  },
};

const ASSETS = CONFIG.MEDIA;

const HOTSPOTS = [
  { id: "staff", label: "Meet the Team", icon: Users, x: 18, y: 32, color: "bg-rose-600", panel: "staff", blurb: "Owners & caretakers who raise your puppy with love." },
  { id: "pack", label: "Our Pack", icon: PawPrint, x: 56, y: 44, color: "bg-amber-600", panel: "pack", blurb: "Puppies with their mature Golden companions." },
  { id: "door", label: "Step Outside", icon: DoorOpen, x: 78, y: 68, color: "bg-emerald-600", panel: "outside", blurb: "Go to the yard—click to play the video." },
  { id: "info", label: "Info Table", icon: Info, x: 34, y: 70, color: "bg-indigo-600", panel: "info", blurb: "Pricing, go‑home dates, what’s included, apply." },
];

export default function App() {
  const [panel, setPanel] = useState(null);
  useEffect(() => {
    console.assert(Array.isArray(ASSETS.STAFF) && ASSETS.STAFF.length >= 2, "Expect at least 2 staff placeholders");
    console.assert(Array.isArray(ASSETS.PACK) && ASSETS.PACK.length >= 3, "Expect 3+ pack photos");
    console.assert(typeof CONFIG.MEDIA.OUTSIDE_VIDEO === "string" && CONFIG.MEDIA.OUTSIDE_VIDEO.length > 0, "Outside video URL missing");
  }, []);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-rose-50 via-white to-amber-50 text-slate-800">
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b border-slate-200/40">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Dog className="w-7 h-7 text-amber-600" />
            <div className="leading-tight">
              <h1 className="text-lg font-semibold">Classic Heritage Golden Retrievers</h1>
              <p className="text-xs text-slate-500">Health‑tested • Family‑raised • Southern California</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-4 text-sm">
            <button className="hover:text-amber-600" onClick={() => setPanel("info")}>Info Table</button>
            <button className="hover:text-amber-600" onClick={() => setPanel("staff")}>Team</button>
            <button className="hover:text-amber-600" onClick={() => setPanel("pack")}>Our Pack</button>
            <button className="hover:text-amber-600" onClick={() => setPanel("outside")}>Outside</button>
          </nav>
        </div>
      </header>

      <section className="relative">
        <div className="mx-auto max-w-7xl px-4 py-10 md:py-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight">Explore our <span className="text-amber-600">Kennel</span></h2>
              <p className="mt-4 text-slate-600 max-w-prose">
                Click around the landing scene: meet our team, see puppies with their older companions, step outside to watch
                the yard video, or visit the information table for pricing, go‑home dates, and application links.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={() => setPanel("pack")} className="px-4 py-2 rounded-xl bg-amber-600 text-white shadow hover:bg-amber-700">See the Pack</button>
                <button onClick={() => setPanel("info")} className="px-4 py-2 rounded-xl border border-amber-600 text-amber-700 bg-white/80 hover:bg-amber-50">Info Table</button>
              </div>
              <div className="mt-6 flex items-center gap-3 text-sm text-slate-500">
                <MapPin className="w-4 h-4" /> Southern California • Visits by appointment
              </div>
            </div>

            <div className="relative h-[520px] md:h-[560px]">
              <div className="absolute inset-0 rounded-[40px] bg-gradient-to-br from-amber-100 via-white to-rose-100 border border-white shadow-2xl overflow-hidden">
                <div className="absolute -top-20 -left-16 w-72 h-72 rounded-full bg-amber-200/60 blur-3xl" />
                <div className="absolute -bottom-20 -right-16 w-96 h-96 rounded-full bg-rose-200/60 blur-3xl" />
                {HOTSPOTS.map((h) => (
                  <button key={h.id} onClick={() => setPanel(h.panel)} className="group absolute -translate-x-1/2 -translate-y-1/2"
                    style={{ left: `${h.x}%`, top: `${h.y}%` }} aria-label={h.label}>
                    <div className="rounded-2xl shadow-xl bg-white/85 backdrop-blur border border-white/60 p-4 w-[240px] text-left">
                      <div className="flex items-start gap-3">
                        <div className={`rounded-xl p-2 text-white ${h.color}`}><h.icon className="w-5 h-5" /></div>
                        <div><div className="font-semibold leading-tight">{h.label}</div><div className="text-xs text-slate-500 mt-1">{h.blurb}</div></div>
                      </div>
                    </div>
                  </button>
                ))}
                <div className="absolute left-6 bottom-6 flex items-center gap-2 text-slate-500 text-sm">
                  <Info className="w-4 h-4" /> Click any card to open details
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {panel && (
        <div className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-end md:items-center justify-center p-4" onClick={() => setPanel(null)}>
          <div className="w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <div className="rounded-2xl shadow-2xl bg-white p-5 md:p-6">
              {panel === "staff" && <StaffPanel onClose={() => setPanel(null)} />}
              {panel === "pack" && <PackPanel onClose={() => setPanel(null)} />}
              {panel === "outside" && <OutsidePanel onClose={() => setPanel(null)} />}
              {panel === "info" && <InfoPanel goContact={() => setPanel("contact")} onClose={() => setPanel(null)} />}
              {panel === "contact" && <ContactPanel onClose={() => setPanel(null)} />}
            </div>
          </div>
        </div>
      )}

      <footer className="mt-16 border-t bg-white/60">
        <div className="mx-auto max-w-7xl px-4 py-8 grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="flex items-center gap-2 mb-2"><Dog className="w-5 h-5 text-amber-600" /><span className="font-semibold">Classic Heritage</span></div>
            <p className="text-slate-600">AKC Golden Retrievers • Health‑tested • Family‑raised.</p>
          </div>
          <div>
            <div className="font-semibold mb-2">Contact</div>
            <div className="space-y-1 text-slate-600">
              <div className="flex items-center gap-2"><Phone className="w-4 h-4" /> (xxx) xxx‑xxxx</div>
              <div className="flex items-center gap-2"><Mail className="w-4 h-4" /> hello@classicheritagegoldenretrievers.com</div>
            </div>
          </div>
          <div>
            <div className="font-semibold mb-2">Visit</div>
            <div className="flex items-center gap-2 text-slate-600"><MapPin className="w-4 h-4" /> Southern California • By appointment</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function StaffPanel({ onClose }) {
  return (
    <div>
      <PanelHeader icon={Users} title="Meet the Team" onClose={onClose} />
      <div className="grid sm:grid-cols-2 gap-4">
        {ASSETS.STAFF.map((s) => (
          <div key={s.name} className="rounded-2xl border bg-white overflow-hidden shadow">
            <div className="aspect-video bg-slate-100"><img src={s.img} alt={s.name} className="w-full h-full object-cover" /></div>
            <div className="p-4"><div className="font-semibold">{s.name}</div><div className="text-sm text-slate-600">{s.role}</div></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PackPanel({ onClose }) {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [index, setIndex] = useState(0);
  return (
    <div>
      <PanelHeader icon={PawPrint} title="Puppies & Companions" onClose={onClose} />
      <div className="grid md:grid-cols-3 gap-4">
        {ASSETS.PACK.map((url, i) => (
          <button key={i} className="rounded-2xl border bg-white overflow-hidden shadow text-left"
            onClick={() => { setIndex(i); setLightboxOpen(true); }} aria-label={`Open pack photo ${i + 1}`}>
            <div className="aspect-square bg-slate-100"><img src={url} alt={`Pack photo ${i + 1}`} className="w-full h-full object-cover" /></div>
          </button>
        ))}
      </div>
      <p className="mt-3 text-sm text-slate-600">Temperament, socialization, and health are our priority. Ask about upcoming litters and availability.</p>
      {lightboxOpen && (
        <div className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setLightboxOpen(false)}>
          <div className="max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <div className="relative rounded-2xl overflow-hidden border bg-black">
              <img src={ASSETS.PACK[index]} alt={`Pack large ${index + 1}`} className="w-full h-full object-contain" />
              <button onClick={() => setLightboxOpen(false)} className="absolute top-3 right-3 rounded-xl border bg-white/80 px-3 py-1">Close</button>
              <div className="absolute inset-y-0 left-0 flex items-center">
                <button onClick={() => setIndex((i) => (i - 1 + ASSETS.PACK.length) % ASSETS.PACK.length)} className="mx-2 rounded-full bg-white/80 px-3 py-2">‹</button>
              </div>
              <div className="absolute inset-y-0 right-0 flex items-center">
                <button onClick={() => setIndex((i) => (i + 1) % ASSETS.PACK.length)} className="mx-2 rounded-full bg-white/80 px-3 py-2">›</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function OutsidePanel({ onClose }) {
  const videoRef = useRef(null);
  const [started, setStarted] = useState(false);
  const handleStart = async () => {
    if (!videoRef.current) return;
    try { await videoRef.current.play(); setStarted(true); } catch { setStarted(false); }
  };
  return (
    <div>
      <PanelHeader icon={DoorOpen} title="Outside Space" onClose={onClose} />
      <div className="rounded-2xl overflow-hidden border bg-black relative">
        <video ref={videoRef} poster={ASSETS.OUTSIDE_POSTER} src={ASSETS.OUTSIDE_VIDEO} className="w-full h-full" playsInline controls={started} />
        {!started && (
          <button onClick={handleStart} className="absolute inset-0 m-auto h-16 w-16 flex items-center justify-center rounded-full bg-white/80 shadow hover:bg-white" aria-label="Play yard video">
            <Play className="w-7 h-7 text-amber-700" />
          </button>
        )}
      </div>
      <div className="mt-3 text-sm text-slate-600 flex items-center gap-2"><Play className="w-4 h-4" /> Click the play button to start the yard video.</div>
    </div>
  );
}

function InfoPanel({ onClose, goContact }) {
  const [trainingAddon, setTrainingAddon] = useState(false);
  const [deliveryAddon, setDeliveryAddon] = useState(false);
  const BASE_PRICE = CONFIG.PRICING.BASE, TRAINING = CONFIG.PRICING.TRAINING, DELIVERY = CONFIG.PRICING.DELIVERY;
  const total = useMemo(() => BASE_PRICE + (trainingAddon ? TRAINING : 0) + (deliveryAddon ? DELIVERY : 0), [trainingAddon, deliveryAddon]);
  return (
    <div>
      <PanelHeader icon={Info} title="Information Table" onClose={onClose} />
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Openings & Go‑Home Dates</div>
          <ul className="mt-2 text-sm list-disc list-inside text-slate-700">
            <li><span className="font-medium">Vivienne</span> — openings; go‑home <em>Mar 29–30</em></li>
            <li><span className="font-medium">Chloe</span> — openings; go‑home <em>Apr 13–14</em></li>
          </ul>
          <a href={CONFIG.LINKS.APPLY} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 mt-3 text-amber-700 hover:underline"><ClipboardList className="w-4 h-4" /> Start Application</a>
        </div>
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Pricing (Interactive)</div>
          <div className="mt-2 text-sm text-slate-700 space-y-2">
            <div className="flex items-center justify-between"><span>Puppy (base)</span><span className="font-medium">${BASE_PRICE.toLocaleString()}</span></div>
            <label className="flex items-center justify-between gap-3"><span>Starter Training Add‑on</span><input type="checkbox" className="h-4 w-4" checked={trainingAddon} onChange={e => setTrainingAddon(e.target.checked)} /></label>
            <label className="flex items-center justify-between gap-3"><span>Regional Delivery</span><input type="checkbox" className="h-4 w-4" checked={deliveryAddon} onChange={e => setDeliveryAddon(e.target.checked)} /></label>
            <div className="pt-2 border-t flex items-center justify-between text-base"><span>Total</span><span className="font-semibold">${total.toLocaleString()}</span></div>
            <div className="flex gap-3 pt-2">
              <a href={CONFIG.LINKS.APPLY} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-xl bg-amber-600 text-white hover:bg-amber-700 inline-flex items-center gap-2"><ClipboardList className="w-4 h-4" /> Apply Now</a>
              <a href={CONFIG.LINKS.PRICING} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-xl border border-amber-600 text-amber-700 hover:bg-amber-50 inline-flex items-center gap-2"><ExternalLink className="w-4 h-4" /> Full Pricing</a>
            </div>
          </div>
        </div>
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Health & What’s Included</div>
          <ul className="mt-2 text-sm list-disc list-inside text-slate-700">
            <li>Vet exam, age‑appropriate vaccinations, deworming</li>
            <li>Microchip, starter kit, lifetime breeder support</li>
            <li>OFA/eyes/heart on parents • Genetic panel</li>
          </ul>
          <a href={CONFIG.LINKS.PRICING} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 mt-3 text-amber-700 hover:underline"><ShieldCheck className="w-4 h-4" /> Health Details</a>
        </div>
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Questions? Drop us a note</div>
          <div className="mt-3">
            <button onClick={goContact} className="w-full rounded-2xl border bg-slate-50 hover:bg-slate-100 py-6 relative">
              <div className="absolute left-1/2 -translate-x-1/2 -top-3 w-40 h-2 bg-slate-400 rounded"></div>
              <div className="flex items-center justify-center gap-2 text-amber-700 font-medium"><Mail className="w-5 h-5" /> Open Mail Slot</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ContactPanel({ onClose }) {
  return (
    <div>
      <PanelHeader icon={Mail} title="Contact Us" onClose={onClose} />
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Send a Message</div>
          <form className="mt-3 grid gap-3" onSubmit={(e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const name = form.querySelector('input[name="name"]').value;
            const email = form.querySelector('input[name="email"]').value;
            const msg = form.querySelector('textarea[name="msg"]').value;
            const mailto = `mailto:hello@classicheritagegoldenretrievers.com?subject=Puppy%20Inquiry%20from%20${encodeURIComponent(name)}&body=${encodeURIComponent(msg + "\\n\\nFrom: " + name + " (" + email + ")")}`;
            window.location.href = mailto;
          }}>
            <input name="name" className="px-3 py-2 rounded-xl border" placeholder="Your name" required />
            <input name="email" className="px-3 py-2 rounded-xl border" placeholder="Email" type="email" required />
            <textarea name="msg" className="px-3 py-2 rounded-xl border min-h-[120px]" placeholder="How can we help?" required />
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 rounded-xl bg-amber-600 text-white hover:bg-amber-700 w-max" type="submit">Send</button>
              <a href={CONFIG.LINKS.CONTACT} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-xl border border-amber-600 text-amber-700 hover:bg-amber-50 inline-flex items-center gap-2">Open Contact Page</a>
            </div>
          </form>
        </div>
        <div className="rounded-2xl border bg-white p-4">
          <div className="font-semibold">Other Ways to Reach Us</div>
          <div className="mt-2 text-sm text-slate-700 space-y-2">
            <div className="flex items-center gap-2"><Phone className="w-4 h-4" /> (xxx) xxx‑xxxx</div>
            <div className="flex items-center gap-2"><Mail className="w-4 h-4" /> hello@classicheritagegoldenretrievers.com</div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /> Southern California • By appointment</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PanelHeader({ icon: Icon, title, onClose }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-3"><Icon className="w-5 h-5" /><h3 className="text-lg md:text-2xl font-semibold">{title}</h3></div>
      <button onClick={onClose} className="rounded-xl border px-3 py-1 hover:bg-slate-50">Close</button>
    </div>
  );
}
